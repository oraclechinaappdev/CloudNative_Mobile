module.exports = function(service) {


	/**
	 *  The file samples.txt in the archive that this file was packaged with contains some example code.
	 */

	 var locations = require('./lib/locations.json');
	 var async = require('async');
	 var BaiduPush = require('baidu_push');
	 var sender = new BaiduPush({
		 	apiKey: 'cZBwyZ9gmlkAYwsOP1Y6Auwu',
		 	secretKey: 'qM9ApHOFzaxSduau37a9QGCEHG5eVbgI'
	 	});


  service.post(locations.apiBaseURI + 'notifyAll', function(req,res) {

		var type = req.body.type;
		var title = req.body.title;
		var description = req.body.description;
		var sdk = req.oracleMobile;
		
		var handler = function (err, result) {
			/* On success, result has the value of body from
			* the last call
			*/
			if (err) {
				res.send(500, err);
			}else {
				res.send(result);
			}
			res.end();
		};

		sender.pushAll({
			
			msg_type: 1,
			msg: JSON.stringify({"title":title,"description":description})
		}, function (err, data) {
			if(err){
				console.log("push notification is failed, err is " + err);
				handler(err,null);
			}else if(data.error_code){
				console.log("push notification is done " );
				handler(null,data);
			}else{
				handler(null,data);
				
			}
		});
		
  });
  
    service.post(locations.apiBaseURI + 'notifyByTag', function(req,res) {

		var type = req.query.type;
		var tag = "" ;
		var title = req.query.title;
		var description = req.query.description;
		var sendon ;
		var sdk = req.oracleMobile;
		var seriesState = {cids: undefined};
		var handler = function (err, result) {
			/* On success, result has the value of body from
			* the last call
			*/
			if (err) {
				res.send(500, err);
			}else {
				res.send(result);
			}
			res.end();
		};

		if (!req.query.tag){
			res.send("400","parameter tag is null");
			res.end();

		}else{
			tag = req.query.tag;
		
			sender.pushTags({
				
				tag: tag,
				type: 1,
				msg_type:1,
				msg: JSON.stringify({"title":title,"description":description})
			}, function (err, data) {
					if(err){
						console.log("push notification is failed, err is " + err);
						handler(err,null);
					}else if(data.error_code){
						console.log("push notification is done " );
						handler(null,data )	;	
					}else{
						handler(null,data )	;	
						sender.reportQueryMsgStatus({
							msg_id: '['+ data.response_params.msg_id +']'
						}, function (err, result) {
							console.log("err: "+err +",result:"+result );
						});
					}
			});				
		}



		
	});
};
