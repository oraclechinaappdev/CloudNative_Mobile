

The following artifacts are included in this package:
    Client MyAndroidClient16 v1.0.0
    MobileBackend LoyaltyMgmt_MBE16 v1.0
    API LoyaltyMgmt16 v.1.0 => APIImplementation LoyaltyMgmt16 v1.0
    Connector GenerateQRCode16 v1.0
    Connector ProcessOffer16 v1.0
    Connector QueryOffers16 v1.0
    UserRealm Default v1.0
