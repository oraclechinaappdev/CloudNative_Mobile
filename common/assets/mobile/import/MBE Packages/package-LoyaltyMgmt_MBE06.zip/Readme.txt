

The following artifacts are included in this package:
    Client MyAndroidClient06 v1.0.0
    MobileBackend LoyaltyMgmt_MBE06 v1.0
    API LoyaltyMgmt06 v.1.0 => APIImplementation LoyaltyMgmt06 v1.0
    Connector GenerateQRCode06 v1.0
    Connector ProcessOffer06 v1.0
    Connector QueryOffers06 v1.0
    UserRealm Default v1.0
