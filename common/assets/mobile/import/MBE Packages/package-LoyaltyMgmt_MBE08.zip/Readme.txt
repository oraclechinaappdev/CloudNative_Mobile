

The following artifacts are included in this package:
    Client MyAndroidClient08 v1.0.0
    MobileBackend LoyaltyMgmt_MBE08 v1.0
    API LoyaltyMgmt08 v.1.0 => APIImplementation LoyaltyMgmt08 v1.0
    Connector GenerateQRCode08 v1.0
    Connector ProcessOffer08 v1.0
    Connector QueryOffers08 v1.0
    UserRealm Default v1.0
